// js/cart.js

document.addEventListener('DOMContentLoaded', () => {
    renderCartPage();
});

const renderCartPage = () => {
    const cartContainer = document.getElementById('cart-items-container') || document.getElementById('cart-items');
    const summaryContainer = document.getElementById('cart-summary') || document.getElementById('order-summary');
    const emptyCartDiv = document.getElementById('empty-cart') || document.getElementById('no-items');

    const cart = JSON.parse(localStorage.getItem('adz_cart')) || [];
    const products = JSON.parse(localStorage.getItem('adz_products')) || [];

    // If Cart is completely empty
    if (cart.length === 0) {
        if (cartContainer) cartContainer.innerHTML = '';
        if (emptyCartDiv) emptyCartDiv.style.display = 'block';
        if (summaryContainer) summaryContainer.style.display = 'none';
        return;
    }

    // Hide empty state if items exist
    if (emptyCartDiv) emptyCartDiv.style.display = 'none';
    if (summaryContainer) summaryContainer.style.display = 'block';

    let subtotal = 0;

    // Render Cart Items
    if (cartContainer) {
        cartContainer.innerHTML = cart.map(item => {
            // Find product matching either productId or standard id (handles both formats safely)
            const targetId = item.productId || item.id;
            const product = products.find(p => p.id === targetId);
            
            // Fallback safety shield to prevent page crashes if data is missing
            if (!product) return '';

            const itemPrice = item.price || product.price;
            const itemTotal = itemPrice * item.quantity;
            subtotal += itemTotal;

            // Normalize unique identifier for dataset references
            const trackingId = item.cartItemId || targetId;

            return `
                <div class="cart-item" style="display: flex; align-items: center; justify-content: space-between; padding: 1.5rem 0; border-bottom: 1px solid var(--border);">
                    <div style="display: flex; align-items: center; gap: 1.5rem;">
                        <img src="${product.images[0]}" alt="${product.name}" style="width: 80px; height: 100px; object-fit: cover; border-radius: var(--radius);">
                        <div>
                            <h3 style="font-size: 1.1rem; margin-bottom: 0.3rem;">${product.name}</h3>
                            <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 0.5rem;">
                                Size: <strong>${item.size || 'Standard'}</strong> | Color: <strong>${item.color || 'Standard'}</strong>
                            </p>
                            <span style="font-weight: 600;">₹${itemPrice.toLocaleString('en-IN')}</span>
                        </div>
                    </div>
                    
                    <div style="display: flex; align-items: center; gap: 2rem;">
                        <div class="quantity-control" style="display: flex; align-items: center; border: 1px solid var(--border); border-radius: 4px;">
                            <button onclick="updateQty('${trackingId}', ${item.quantity - 1})" style="padding: 0.5rem 0.8rem; background: transparent; border: none; cursor: pointer;">-</button>
                            <span style="padding: 0 0.5rem; font-weight: 600;">${item.quantity}</span>
                            <button onclick="updateQty('${trackingId}', ${item.quantity + 1})" style="padding: 0.5rem 0.8rem; background: transparent; border: none; cursor: pointer;">+</button>
                        </div>
                        <button onclick="removeCartItem('${trackingId}')" style="background: transparent; border: none; color: #EF4444; cursor: pointer; font-size: 1.1rem;" title="Remove Item">
                            <i class="fa-regular fa-trash-can"></i>
                        </button>
                    </div>
                </div>
            `;
        }).join('');
    }

    // Render Order Summary Details
    if (summaryContainer) {
        const deliveryFee = subtotal > 1500 ? 0 : 99;
        const grandTotal = subtotal + deliveryFee;

        summaryContainer.innerHTML = `
            <div style="background: var(--card-bg); border: 1px solid var(--border); padding: 2rem; border-radius: var(--radius); position: sticky; top: 110px;">
                <h3 style="margin-bottom: 1.5rem; border-bottom: 1px solid var(--border); padding-bottom: 0.8rem;">Order Summary</h3>
                <div style="display: flex; justify-content: space-between; margin-bottom: 1rem; color: var(--text-muted);">
                    <span>Subtotal</span>
                    <span>₹${subtotal.toLocaleString('en-IN')}</span>
                </div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 1.5rem; color: var(--text-muted);">
                    <span>Delivery Charges</span>
                    <span>${deliveryFee === 0 ? '<span style="color: #10B981; font-weight: 600;">FREE</span>' : `₹${deliveryFee}`}</span>
                </div>
                <div style="display: flex; justify-content: space-between; margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px dashed var(--border); font-size: 1.2rem; font-weight: 700; margin-bottom: 2rem;">
                    <span>Grand Total</span>
                    <span>₹${grandTotal.toLocaleString('en-IN')}</span>
                </div>
                <a href="checkout.html" class="btn btn-primary" style="display: block; text-align: center; width: 100%; text-decoration: none;">Proceed to Checkout</a>
            </div>
        `;
    }
};

// Global Handler to Modify Item Quantities
window.updateQty = (trackingId, newQty) => {
    let cart = JSON.parse(localStorage.getItem('adz_cart')) || [];
    
    if (newQty <= 0) {
        removeCartItem(trackingId);
        return;
    }

    const item = cart.find(i => (i.cartItemId === trackingId || i.id === trackingId || `${i.productId}-${i.size}-${i.color}` === trackingId));
    if (item) {
        item.quantity = newQty;
        localStorage.setItem('adz_cart', JSON.stringify(cart));
        renderCartPage();
        if (typeof window.updateNavbarBadges === 'function') window.updateNavbarBadges();
    }
};

// Global Handler to Delete Items Entirely
window.removeCartItem = (trackingId) => {
    let cart = JSON.parse(localStorage.getItem('adz_cart')) || [];
    
    cart = cart.filter(i => !(i.cartItemId === trackingId || i.id === trackingId || `${i.productId}-${i.size}-${i.color}` === trackingId));
    
    localStorage.setItem('adz_cart', JSON.stringify(cart));
    renderCartPage();
    if (typeof window.updateNavbarBadges === 'function') window.updateNavbarBadges();
    if (typeof window.showToast === 'function') window.showToast('Item removed from cart.', 'info');
};

// Expose rendering loop to the global scope context
window.renderCartPage = renderCartPage;
