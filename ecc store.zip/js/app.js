// js/app.js

document.addEventListener('DOMContentLoaded', () => {
    // 1. Theme Management
    const themeToggleBtn = document.getElementById('theme-toggle');
    const htmlElement = document.documentElement;
    
    // Check local storage for theme
    const savedTheme = localStorage.getItem('adz_theme') || 'light';
    htmlElement.setAttribute('data-theme', savedTheme);
    updateThemeIcon(savedTheme);

    if (themeToggleBtn) {
        themeToggleBtn.addEventListener('click', () => {
            let currentTheme = htmlElement.getAttribute('data-theme');
            let newTheme = currentTheme === 'light' ? 'dark' : 'light';
            
            htmlElement.setAttribute('data-theme', newTheme);
            localStorage.setItem('adz_theme', newTheme);
            updateThemeIcon(newTheme);
        });
    }

    function updateThemeIcon(theme) {
        if (!themeToggleBtn) return;
        if(theme === 'dark') {
            themeToggleBtn.classList.remove('fa-moon');
            themeToggleBtn.classList.add('fa-sun');
        } else {
            themeToggleBtn.classList.remove('fa-sun');
            themeToggleBtn.classList.add('fa-moon');
        }
    }

    // 2. Sticky Navbar & Scroll Effects
    const navbar = document.getElementById('navbar');
    
    window.addEventListener('scroll', () => {
        if (navbar) {
            if (window.scrollY > 50) {
                navbar.style.boxShadow = 'var(--shadow)';
                navbar.style.height = '70px';
            } else {
                navbar.style.boxShadow = 'none';
                navbar.style.height = '80px';
            }
        }
    });

    // 3. Setup Global LocalStorage Arrays if not present
    const storageKeys = ['adz_cart', 'adz_wishlist', 'adz_orders', 'adz_users', 'adz_recently_viewed'];
    storageKeys.forEach(key => {
        if (!localStorage.getItem(key)) {
            localStorage.setItem(key, JSON.stringify([]));
        }
    });
});

// --- Global Utilities ---

// Currency Formatter (INR for India context)
const formatPrice = (price) => {
    return `₹${price.toLocaleString('en-IN')}`;
};

// Calculate Sale Price
const getSalePrice = (price, discount) => {
    if (!discount) return price;
    return Math.round(price - (price * (discount / 100)));
};

// Generate Star Rating HTML
const generateStars = (rating) => {
    let starsHtml = '';
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    for (let i = 0; i < fullStars; i++) starsHtml += '<i class="fa-solid fa-star"></i>';
    if (hasHalfStar) starsHtml += '<i class="fa-solid fa-star-half-stroke"></i>';
    
    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) starsHtml += '<i class="fa-regular fa-star"></i>';
    
    return starsHtml;
};

// Toast Notification System
const showToast = (message, type = 'success') => {
    const container = document.getElementById('toast-container');
    if (!container) return;
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    const icon = type === 'success' ? 'fa-circle-check' : 'fa-circle-exclamation';
    
    toast.innerHTML = `
        <i class="fa-solid ${icon}"></i>
        <span>${message}</span>
    `;
    
    container.appendChild(toast);
    
    // Trigger animation
    setTimeout(() => toast.classList.add('show'), 10);
    
    // Remove toast
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 400); // Wait for transition out
    }, 3000);
};

// --- Featured Products Logic ---

// Fetch products from LocalStorage
const allProducts = JSON.parse(localStorage.getItem('adz_products')) || [];

const featuredGrid = document.getElementById('featured-grid');
const tabButtons = document.querySelectorAll('.tab-btn');

// Render Skeleton Loaders
const renderSkeletons = (count = 8) => {
    if (!featuredGrid) return;
    featuredGrid.innerHTML = Array(count).fill(`
        <div class="product-card" style="box-shadow: none; border: none;">
            <div class="skeleton skeleton-img"></div>
            <div class="skeleton skeleton-text" style="margin-top: 20px;"></div>
            <div class="skeleton skeleton-text short"></div>
            <div class="skeleton skeleton-text price"></div>
        </div>
    `).join('');
};

// Render Actual Product Cards
const renderFeaturedProducts = (filterType) => {
    if (!featuredGrid) return;
    renderSkeletons();
    
    setTimeout(() => {
        let filteredProducts = [];
        
        switch(filterType) {
            case 'best':
                filteredProducts = [...allProducts].sort((a, b) => b.rating - a.rating).slice(0, 8);
                break;
            case 'new':
                filteredProducts = [...allProducts].reverse().slice(0, 8);
                break;
            case 'trending':
                filteredProducts = [...allProducts].sort((a, b) => b.stock - a.stock).slice(0, 8);
                break;
            case 'sale':
                filteredProducts = allProducts.filter(p => p.discount > 0).sort((a, b) => b.discount - a.discount).slice(0, 8);
                break;
        }

        if(filteredProducts.length === 0) {
            featuredGrid.innerHTML = '<p style="text-align: center; width: 100%; color: var(--text-muted);">No products found.</p>';
            return;
        }

        featuredGrid.innerHTML = filteredProducts.map(product => {
            const salePrice = getSalePrice(product.price, product.discount);
            const discountBadge = product.discount > 0 ? `<div class="discount-badge">-${product.discount}%</div>` : '';
            const priceHtml = product.discount > 0 
                ? `<span class="sale-price">${formatPrice(salePrice)}</span> <span class="original-price">${formatPrice(product.price)}</span>`
                : `<span class="sale-price">${formatPrice(product.price)}</span>`;

            return `
                <div class="product-card">
                    ${discountBadge}
                    <div class="product-image-container">
                        <img src="${product.images[0]}" alt="${product.name}" loading="lazy">
                        <div class="card-actions">
                            <button class="action-btn" onclick="openQuickView(${product.id})" title="Quick View">
                                <i class="fa-regular fa-eye"></i>
                            </button>
                            <button class="action-btn" onclick="toggleWishlist(${product.id}, this)" title="Add to Wishlist">
                                <i class="fa-regular fa-heart"></i>
                            </button>
                            <button class="action-btn" onclick="addToCart(${product.id})" title="Add to Cart">
                                <i class="fa-solid fa-cart-plus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="product-info">
                        <div class="brand-name">${product.brand}</div>
                        <h3 class="product-name">${product.name}</h3>
                        <div class="product-rating">
                            ${generateStars(product.rating)}
                            <span>(${Math.floor(Math.random() * 500) + 50})</span>
                        </div>
                        <div class="product-price">${priceHtml}</div>
                    </div>
                </div>
            `;
        }).join('');
    }, 800);
};

// Tab Click Event Listeners
if(tabButtons.length > 0) {
    tabButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            tabButtons.forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            const filter = e.target.getAttribute('data-filter');
            renderFeaturedProducts(filter);
        });
    });
    
    renderFeaturedProducts('best');
}

// --- Modal Quick View Logic ---

const modalOverlay = document.getElementById('quick-view-modal');
const modalClose = document.getElementById('modal-close');
const modalBody = document.getElementById('modal-body');

const openQuickView = (productId) => {
    const product = allProducts.find(p => p.id === productId);
    if (!product || !modalBody || !modalOverlay) return;

    const salePrice = getSalePrice(product.price, product.discount);
    const colorsHtml = product.colors.map((c, i) => `<button class="option-btn ${i===0?'selected':''}">${c}</button>`).join('');
    const sizesHtml = product.sizes.map((s, i) => `<button class="option-btn ${i===0?'selected':''}">${s}</button>`).join('');

    modalBody.innerHTML = `
        <div class="modal-gallery">
            <img src="${product.images[0]}" alt="${product.name}">
        </div>
        <div class="modal-info">
            <div class="brand-name">${product.brand}</div>
            <h2>${product.name}</h2>
            <div class="product-rating" style="margin-bottom: 1rem;">
                ${generateStars(product.rating)} <span>${product.rating}</span>
            </div>
            <div class="product-price" style="font-size: 1.5rem;">
                <span class="sale-price" style="font-size: 1.8rem;">${formatPrice(salePrice)}</span>
                ${product.discount > 0 ? `<span class="original-price">${formatPrice(product.price)}</span>` : ''}
            </div>
            <p class="modal-desc">${product.description}</p>
            
            <div class="selection-group">
                <h4>Color</h4>
                <div class="options-flex">${colorsHtml}</div>
            </div>
            <div class="selection-group">
                <h4>Size</h4>
                <div class="options-flex">${sizesHtml}</div>
            </div>
            
            <div class="modal-actions">
                <button class="btn btn-outline" style="margin-left: 0;" onclick="toggleWishlist(${product.id}, this)">
                    <i class="fa-regular fa-heart"></i> Wishlist
                </button>
                <button class="btn btn-primary" onclick="addToCart(${product.id})">
                    <i class="fa-solid fa-bag-shopping"></i> Add to Cart
                </button>
            </div>
        </div>
    `;

    const optionBtns = modalBody.querySelectorAll('.option-btn');
    optionBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const siblings = e.target.parentElement.querySelectorAll('.option-btn');
            siblings.forEach(s => s.classList.remove('selected'));
            e.target.classList.add('selected');
        });
    });

    modalOverlay.classList.add('active');
    document.body.style.overflow = 'hidden';
};

if(modalClose && modalOverlay) {
    modalClose.addEventListener('click', () => {
        modalOverlay.classList.remove('active');
        document.body.style.overflow = 'auto';
    });

    modalOverlay.addEventListener('click', (e) => {
        if (e.target === modalOverlay) {
            modalOverlay.classList.remove('active');
            document.body.style.overflow = 'auto';
        }
    });
}

// --- Dynamic Storage Core Engines ---

window.addToCart = (productId) => {
    const product = allProducts.find(p => p.id === productId);
    if (!product) return;

    const size = product.sizes ? product.sizes[0] : 'Standard';
    const color = product.colors ? product.colors[0] : 'Standard';
    const cartItemId = `${productId}-${size}-${color}`;
    
    let cart = JSON.parse(localStorage.getItem('adz_cart')) || [];
    const existingItem = cart.find(item => item.cartItemId === cartItemId);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            cartItemId,
            productId,
            size,
            color,
            quantity: 1,
            price: getSalePrice(product.price, product.discount)
        });
    }

    localStorage.setItem('adz_cart', JSON.stringify(cart));
    showToast(`${product.name} added to cart!`, 'success');
    
    if (typeof window.updateNavbarBadges === 'function') window.updateNavbarBadges();
    if (typeof window.renderCartPage === 'function') window.renderCartPage();
};

window.toggleWishlist = (productId, btnElement) => {
    const product = allProducts.find(p => p.id === productId);
    if (!product) return;

    let wishlist = JSON.parse(localStorage.getItem('adz_wishlist')) || [];
    const index = wishlist.indexOf(productId);
    let added = false;

    if (index === -1) {
        wishlist.push(productId);
        added = true;
        showToast(`${product.name} added to wishlist!`, 'success');
    } else {
        wishlist.splice(index, 1);
        showToast(`${product.name} removed from wishlist.`, 'success');
    }

    localStorage.setItem('adz_wishlist', JSON.stringify(wishlist));
    
    if (btnElement) {
        const icon = btnElement.querySelector('i') || btnElement;
        if (added) {
            icon.classList.replace('fa-regular', 'fa-solid');
            icon.style.color = '#EF4444';
        } else {
            icon.classList.replace('fa-solid', 'fa-regular');
            icon.style.color = 'inherit';
        }
    }

    if (typeof window.updateNavbarBadges === 'function') window.updateNavbarBadges();
    if (typeof window.renderWishlistPage === 'function') window.renderWishlistPage();
};

// --- Dynamic Navbar Badges Synchronizer ---
const updateNavbarBadges = () => {
    const wishlist = JSON.parse(localStorage.getItem('adz_wishlist')) || [];
    const cart = JSON.parse(localStorage.getItem('adz_cart')) || [];
    
    const navIconsContainer = document.querySelector('.nav-icons');
    if (!navIconsContainer) return;

    const wishlistLink = navIconsContainer.querySelector('a[href="wishlist.html"]');
    const cartLink = navIconsContainer.querySelector('a[href="cart.html"]');

    if (wishlistLink) {
        const oldBadge = wishlistLink.querySelector('.nav-badge');
        if (oldBadge) oldBadge.remove();
        if (wishlist.length > 0) {
            wishlistLink.insertAdjacentHTML('beforeend', `<span class="nav-badge">${wishlist.length}</span>`);
        }
    }

    if (cartLink) {
        const oldBadge = cartLink.querySelector('.nav-badge');
        if (oldBadge) oldBadge.remove();
        const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
        if (totalItems > 0) {
            cartLink.insertAdjacentHTML('beforeend', `<span class="nav-badge">${totalItems}</span>`);
        }
    }
};

document.addEventListener('DOMContentLoaded', updateNavbarBadges);
window.updateNavbarBadges = updateNavbarBadges;
