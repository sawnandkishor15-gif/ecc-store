// js/orders.js

document.addEventListener('DOMContentLoaded', () => {
    const ordersContainer = document.getElementById('orders-container');
    const noOrdersDiv = document.getElementById('no-orders');
    
    // Check if user is logged in
    const currentUser = JSON.parse(localStorage.getItem('adz_currentUser'));
    const userIcon = document.getElementById('user-icon');
    
    if (currentUser && userIcon) {
        userIcon.innerHTML = `<span style="font-size:0.9rem; font-weight:600;">${currentUser.name.split(' ')[0]}</span>`;
    }

    const orders = JSON.parse(localStorage.getItem('adz_orders')) || [];

    if (orders.length === 0) {
        ordersContainer.style.display = 'none';
        noOrdersDiv.style.display = 'block';
        return;
    }

    ordersContainer.innerHTML = orders.map(order => {
        const itemsHtml = order.items.map(item => {
            const product = JSON.parse(localStorage.getItem('adz_products')).find(p => p.id === item.productId);
            return `
                <div class="order-item-row">
                    <span>${item.quantity}x ${product ? product.name : 'Product'} (${item.size}, ${item.color})</span>
                    <span>₹${(item.price * item.quantity).toLocaleString('en-IN')}</span>
                </div>
            `;
        }).join('');

        return `
            <div class="order-card">
                <div class="order-header">
                    <div>
                        <h3>Order #${order.orderId}</h3>
                        <div style="color: var(--text-muted); font-size: 0.85rem; margin-top: 5px;">Placed on ${order.date}</div>
                    </div>
                    <div>
                        <span class="order-status">${order.status}</span>
                    </div>
                </div>
                <div class="order-items">
                    ${itemsHtml}
                </div>
                <div style="margin-top: 1.5rem; padding-top: 1rem; border-top: 1px dashed var(--border); display: flex; justify-content: space-between; font-weight: 700;">
                    <span>Total Amount</span>
                    <span>${order.total}</span>
                </div>
            </div>
        `;
    }).join('');
});
