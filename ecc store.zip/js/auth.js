// js/auth.js

document.addEventListener('DOMContentLoaded', () => {
    // Show/Hide Password Toggle
    const togglePassBtns = document.querySelectorAll('.toggle-pass');
    togglePassBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const input = this.previousElementSibling;
            if (input.type === "password") {
                input.type = "text";
                this.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                input.type = "password";
                this.classList.replace('fa-eye-slash', 'fa-eye');
            }
        });
    });

    const users = JSON.parse(localStorage.getItem('adz_users')) || [];

    // Register Logic
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const name = document.getElementById('reg-name').value;
            const email = document.getElementById('reg-email').value;
            const pass = document.getElementById('reg-pass').value;

            // Check if user exists
            if (users.find(u => u.email === email)) {
                showToast('Email is already registered!', 'error');
                return;
            }

            users.push({ name, email, password: pass });
            localStorage.setItem('adz_users', JSON.stringify(users));
            showToast('Registration Successful! Redirecting...', 'success');
            
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 1500);
        });
    }

    // Login Logic
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = document.getElementById('login-email').value;
            const pass = document.getElementById('login-pass').value;

            const user = users.find(u => u.email === email && u.password === pass);

            if (user) {
                localStorage.setItem('adz_currentUser', JSON.stringify({ name: user.name, email: user.email }));
                showToast(`Welcome back, ${user.name}!`, 'success');
                
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 1500);
            } else {
                showToast('Invalid Email or Password', 'error');
            }
        });
    }
});
