// js/admin.js

document.addEventListener('DOMContentLoaded', () => {
    // Tab Navigation
    const navItems = document.querySelectorAll('.admin-nav li[data-target]');
    const views = document.querySelectorAll('.admin-view');

    navItems.forEach(item => {
        item.addEventListener('click', () => {
            // Remove active class from all
            navItems.forEach(n => n.classList.remove('active'));
            views.forEach(v => v.classList.remove('active'));
            
            // Add to clicked
            item.classList.add('active');
            const target = item.getAttribute('data-target');
            document.getElementById(`view-${target}`).classList.add('active');
        });
    });

    // Data Fetching
    const products = JSON.parse(localStorage.getItem('adz_products')) || [];
    const orders = JSON.parse(localStorage.getItem('adz_orders')) || [];
    const users = JSON.parse(localStorage.getItem('adz_users')) || [];

    // 1. Render Dashboard Stats
    const totalOrders = orders.length;
    const totalUsers = users.length;
    
    // Calculate total revenue (parse formatted currency string to number)
    let totalRevenue = 0;
    orders.forEach(order => {
        const val = parseInt(order.total.replace(/[^0-9]/g, ''), 10);
        if(!isNaN(val)) totalRevenue += val;
    });

    document.getElementById('stat-revenue').textContent = `₹${totalRevenue.toLocaleString('en-IN')}`;
    document.getElementById('stat-orders').textContent = totalOrders;
    document.getElementById('stat-users').textContent = totalUsers;

    // 2. Render Products Table
    const productsTable = document.getElementById('admin-products-table');
    if (productsTable) {
        productsTable.innerHTML = products.map(p => `
            <tr>
                <td>#${p.id}</td>
                <td><img src="${p.images[0]}" alt="${p.name}"></td>
                <td style="font-weight: 500;">${p.name}</td>
                <td>₹${p.price.toLocaleString('en-IN')}</td>
                <td>${p.stock}</td>
                <td>
                    <button style="border:none; background:transparent; color:#3B82F6; cursor:pointer; margin-right:10px;"><i class="fa-solid fa-pen"></i></button>
                    <button style="border:none; background:transparent; color:#EF4444; cursor:pointer;"><i class="fa-solid fa-trash"></i></button>
                </td>
            </tr>
        `).join('');
    }

    // 3. Render Orders Table
    const ordersTable = document.getElementById('admin-orders-table');
    if (ordersTable) {
        ordersTable.innerHTML = orders.map(o => `
            <tr>
                <td style="font-weight: 600;">${o.orderId}</td>
                <td>${o.date}</td>
                <td>${o.items.reduce((acc, item) => acc + item.quantity, 0)} items</td>
                <td style="font-weight: 600;">${o.total}</td>
                <td><span class="order-status">${o.status}</span></td>
            </tr>
        `).join('');
    }

    // Mock Add Product Action
    const btnAddProduct = document.getElementById('btn-add-product');
    if (btnAddProduct) {
        btnAddProduct.addEventListener('click', () => {
            alert('This would open a modal to add a new product. (Data is currently handled via products.js script injection)');
        });
    }
});
