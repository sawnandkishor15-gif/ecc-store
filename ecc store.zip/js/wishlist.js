// js/wishlist.js

// Initialize Wishlist Array from LocalStorage
let wishlist = JSON.parse(localStorage.getItem('adz_wishlist')) || [];

// Master function to add/remove from wishlist globally
window.toggleWishlist = (productId, btnElement) => {
    const index = wishlist.indexOf(productId);
    const icon = btnElement.querySelector('i');

    if (index === -1) {
        // Add to wishlist
        wishlist.push(productId);
        icon.classList.replace('fa-regular', 'fa-solid');
        icon.style.color = '#EF4444';
        showToast('Added to wishlist!', 'success');
    } else {
        // Remove from wishlist
        wishlist.splice(index, 1);
        icon.classList.replace('fa-solid', 'fa-regular');
        icon.style.color = 'inherit';
        showToast('Removed from wishlist.', 'success');
        window.updateNavbarBadges()
        
        // If we are currently on the wishlist page, re-render the grid
        if (window.location.pathname.includes('wishlist.html')) {
            renderWishlistPage();
        }
    }

    localStorage.setItem('adz_wishlist', JSON.stringify(wishlist));
};

// Check if a product is in the wishlist (Used when rendering cards)
const isWishlisted = (productId) => {
    return wishlist.includes(productId);
};

// Render Wishlist Page specifically
const renderWishlistPage = () => {
    const grid = document.getElementById('wishlist-grid');
    const emptyState = document.getElementById('empty-wishlist');
    
    if (!grid) return; // Exit if not on wishlist.html

    if (wishlist.length === 0) {
        grid.style.display = 'none';
        emptyState.style.display = 'block';
        return;
    }

    grid.style.display = 'grid';
    emptyState.style.display = 'none';

    // Map stored IDs to actual product objects
    const wishlistProducts = wishlist.map(id => allProducts.find(p => p.id === id)).filter(p => p !== undefined);

    grid.innerHTML = wishlistProducts.map(product => {
        const salePrice = getSalePrice(product.price, product.discount);
        return `
            <div class="product-card">
                <div class="product-image-container">
                    <img src="${product.images[0]}" alt="${product.name}" loading="lazy">
                    <div class="card-actions">
                        <button class="action-btn" onclick="openQuickView(${product.id})" title="Quick View">
                            <i class="fa-regular fa-eye"></i>
                        </button>
                        <button class="action-btn" onclick="toggleWishlist(${product.id}, this)" title="Remove from Wishlist">
                            <i class="fa-solid fa-heart" style="color: #EF4444;"></i>
                        </button>
                        <button class="action-btn" onclick="addToCart(${product.id})" title="Add to Cart">
                            <i class="fa-solid fa-cart-plus"></i>
                        </button>
                    </div>
                </div>
                <div class="product-info">
                    <div class="brand-name">${product.brand}</div>
                    <h3 class="product-name">${product.name}</h3>
                    <div class="product-price">
                        <span class="sale-price">${formatPrice(salePrice)}</span>
                    </div>
                </div>
            </div>
        `;
    }).join('');
};

// Initialize render if on wishlist page
document.addEventListener('DOMContentLoaded', renderWishlistPage);
