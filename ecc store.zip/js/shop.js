// js/shop.js

document.addEventListener('DOMContentLoaded', () => {
    const shopGrid = document.getElementById('shop-grid');
    if (!shopGrid) return; // Execute only on shop.html

    const productsPerPage = 12;
    let currentPage = 1;
    let filteredProducts = [...allProducts];

    // Read URL Parameters (e.g., shop.html?category=Men)
    const urlParams = new URLSearchParams(window.location.search);
    const urlCategory = urlParams.get('category');
    const urlFilter = urlParams.get('filter'); // e.g., 'new'

    // DOM Elements
    const filterCategoryContainer = document.getElementById('filter-category');
    const filterBrandContainer = document.getElementById('filter-brand');
    const filterPrice = document.getElementById('filter-price');
    const priceDisplay = document.getElementById('price-display');
    const sortSelect = document.getElementById('sort-select');
    const searchInput = document.getElementById('shop-search');
    const searchSuggestions = document.getElementById('search-suggestions');
    const productCountDisplay = document.getElementById('product-count');
    const paginationContainer = document.getElementById('pagination');
    const clearFiltersBtn = document.getElementById('clear-filters');

    // 1. Generate Sidebar Filters Dynamically
    const categories = [...new Set(allProducts.map(p => p.category))];
    const brands = [...new Set(allProducts.map(p => p.brand))];

    filterCategoryContainer.innerHTML = categories.map(cat => 
        `<label><input type="checkbox" value="${cat}" class="cat-filter" ${urlCategory === cat ? 'checked' : ''}> ${cat}</label>`
    ).join('');

    filterBrandContainer.innerHTML = brands.map(brand => 
        `<label><input type="checkbox" value="${brand}" class="brand-filter"> ${brand}</label>`
    ).join('');

    // 2. Core Filter Engine
    const applyFilters = () => {
        // Gather selected checkboxes
        const selectedCategories = Array.from(document.querySelectorAll('.cat-filter:checked')).map(cb => cb.value);
        const selectedGenders = Array.from(document.querySelectorAll('#filter-gender input:checked')).map(cb => cb.value);
        const selectedBrands = Array.from(document.querySelectorAll('.brand-filter:checked')).map(cb => cb.value);
        const maxPrice = parseInt(filterPrice.value);
        const searchQuery = searchInput.value.toLowerCase();
        const sortBy = sortSelect.value;

        // Filter Array
        filteredProducts = allProducts.filter(p => {
            const salePrice = getSalePrice(p.price, p.discount);
            
            const matchCategory = selectedCategories.length === 0 || selectedCategories.includes(p.category);
            const matchGender = selectedGenders.length === 0 || selectedGenders.includes(p.gender) || p.gender === 'Unisex';
            const matchBrand = selectedBrands.length === 0 || selectedBrands.includes(p.brand);
            const matchPrice = salePrice <= maxPrice;
            const matchSearch = p.name.toLowerCase().includes(searchQuery) || p.brand.toLowerCase().includes(searchQuery);

            return matchCategory && matchGender && matchBrand && matchPrice && matchSearch;
        });

        // URL Filter Check (New Arrivals overrides standard sort temporarily)
        if (urlFilter === 'new') {
             filteredProducts.reverse(); // Mocking newest
        }

        // Apply Sorting
        switch(sortBy) {
            case 'price-low': filteredProducts.sort((a, b) => getSalePrice(a.price, a.discount) - getSalePrice(b.price, b.discount)); break;
            case 'price-high': filteredProducts.sort((a, b) => getSalePrice(b.price, b.discount) - getSalePrice(a.price, a.discount)); break;
            case 'rating': filteredProducts.sort((a, b) => b.rating - a.rating); break;
            case 'newest': filteredProducts.sort((a, b) => b.id - a.id); break;
        }

        currentPage = 1;
        renderShopGrid();
        renderPagination();
    };

    // 3. Render Shop Grid
    const renderShopGrid = () => {
        productCountDisplay.textContent = `Showing ${filteredProducts.length} products`;
        
        if (filteredProducts.length === 0) {
            shopGrid.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 4rem 0;"><i class="fa-solid fa-box-open" style="font-size: 3rem; color: var(--border);"></i><h3 style="margin-top: 1rem;">No products found</h3><p style="color: var(--text-muted);">Try adjusting your filters.</p></div>';
            return;
        }

        const startIndex = (currentPage - 1) * productsPerPage;
        const endIndex = startIndex + productsPerPage;
        const currentProducts = filteredProducts.slice(startIndex, endIndex);

        shopGrid.innerHTML = currentProducts.map(product => {
            const salePrice = getSalePrice(product.price, product.discount);
            const discountBadge = product.discount > 0 ? `<div class="discount-badge">-${product.discount}%</div>` : '';
            const priceHtml = product.discount > 0 
                ? `<span class="sale-price">${formatPrice(salePrice)}</span> <span class="original-price">${formatPrice(product.price)}</span>`
                : `<span class="sale-price">${formatPrice(product.price)}</span>`;
            
            // Check wishlist state to show correct heart icon
            const heartIcon = isWishlisted(product.id) ? `<i class="fa-solid fa-heart" style="color: #EF4444;"></i>` : `<i class="fa-regular fa-heart"></i>`;

            return `
                <div class="product-card">
                    ${discountBadge}
                    <div class="product-image-container">
                        <img src="${product.images[0]}" alt="${product.name}" loading="lazy">
                        <div class="card-actions">
                            <button class="action-btn" onclick="openQuickView(${product.id})" title="Quick View">
                                <i class="fa-regular fa-eye"></i>
                            </button>
                            <button class="action-btn" onclick="toggleWishlist(${product.id}, this)" title="Wishlist">
                                ${heartIcon}
                            </button>
                            <button class="action-btn" onclick="addToCart(${product.id})" title="Add to Cart">
                                <i class="fa-solid fa-cart-plus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="product-info">
                        <div class="brand-name">${product.brand}</div>
                        <h3 class="product-name">${product.name}</h3>
                        <div class="product-price">${priceHtml}</div>
                    </div>
                </div>
            `;
        }).join('');
        
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    // 4. Pagination
    const renderPagination = () => {
        const totalPages = Math.ceil(filteredProducts.length / productsPerPage);
        if (totalPages <= 1) {
            paginationContainer.innerHTML = '';
            return;
        }

        let pagesHtml = '';
        for(let i = 1; i <= totalPages; i++) {
            pagesHtml += `<button class="page-btn ${i === currentPage ? 'active' : ''}" data-page="${i}">${i}</button>`;
        }
        paginationContainer.innerHTML = pagesHtml;

        document.querySelectorAll('.page-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                currentPage = parseInt(e.target.getAttribute('data-page'));
                renderShopGrid();
                renderPagination();
            });
        });
    };

    // 5. Search Suggestions Logic
    searchInput.addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase();
        if (query.length < 2) {
            searchSuggestions.style.display = 'none';
            applyFilters();
            return;
        }

        const matches = allProducts.filter(p => p.name.toLowerCase().includes(query) || p.brand.toLowerCase().includes(query)).slice(0, 5);
        
        if (matches.length > 0) {
            searchSuggestions.innerHTML = matches.map(p => `
                <div class="suggestion-item" onclick="openQuickView(${p.id})">
                    <img src="${p.images[0]}" alt="${p.name}">
                    <div>
                        <div style="font-size: 0.85rem; color: var(--text-muted);">${p.brand}</div>
                        <div style="font-weight: 500; font-size: 0.95rem;">${p.name}</div>
                    </div>
                </div>
            `).join('');
            searchSuggestions.style.display = 'block';
        } else {
            searchSuggestions.style.display = 'none';
        }

        // Apply visual filter to grid as well
        applyFilters();
    });

    // Hide suggestions on outside click
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.search-container')) {
            searchSuggestions.style.display = 'none';
        }
    });

    // 6. Event Listeners for Filters
    document.querySelectorAll('.shop-sidebar input[type="checkbox"]').forEach(cb => cb.addEventListener('change', applyFilters));
    
    filterPrice.addEventListener('input', (e) => {
        priceDisplay.textContent = formatPrice(parseInt(e.target.value));
    });
    filterPrice.addEventListener('change', applyFilters); // Trigger filter on slider release

    sortSelect.addEventListener('change', applyFilters);

    clearFiltersBtn.addEventListener('click', () => {
        document.querySelectorAll('.shop-sidebar input[type="checkbox"]').forEach(cb => cb.checked = false);
        filterPrice.value = 150000;
        priceDisplay.textContent = '₹150,000';
        searchInput.value = '';
        sortSelect.value = 'featured';
        applyFilters();
    });

    // Initialize
    applyFilters();
});
